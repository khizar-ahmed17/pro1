package job;

public class Sample 
{
	public static void main(String[] args)
	{
	System.out.println("fdsfds");	
	}

}
