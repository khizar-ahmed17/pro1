package job;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("requestposition")
public class RequestPosition
{
	
	@Autowired
	ServiceProvider userbean;
	
	public ServiceProvider getUserbean() {
		return userbean;
	}

	public void setUserbean(ServiceProvider userbean) {
		this.userbean = userbean;
	}
	
	
	@Autowired
	ServiceRequester requestbean;
	
	public ServiceRequester getRequestbean() {
		return requestbean;
	}

	public void setRequestbean(ServiceRequester requestbean) {
		this.requestbean = requestbean;
	}


	@Autowired
	Jobs jobbean;
	
	public Jobs getJobbean() {
		return jobbean;
	}

	public void setJobbean(Jobs jobbean) {
		this.jobbean = jobbean;
	}

	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView movetoposition(HttpSession session,Jobs jobbean)
	{
		
String i=(String) session.getAttribute("username");
		
		System.out.println(i);
		if(i==null)
		{
			ServiceProvider userbean=new ServiceProvider();
			ServiceRequester requestbean=new ServiceRequester();
			ModelAndView mdlvie=new ModelAndView();
			mdlvie.setViewName("login");
			mdlvie.addObject("userbean",userbean);
			
			mdlvie.addObject("requestbean",requestbean);
			
			return mdlvie;
		}
		else{
		
			System.out.println("In Get method of position");
			ModelAndView md=new ModelAndView();
			Session session1=(Session)SessionUtility.GetSessionConnection();
			Criteria cr = session1.createCriteria(Jobs.class)
				    .setProjection(Projections.projectionList()
				      .add(Projections.property("job_name"), "job_name")
				      .add(Projections.property("job_experience"),"job_experience"))
				    .setResultTransformer(Transformers.aliasToBean(Jobs.class));

				  List<Jobs> list = cr.list();
				  Iterator<Jobs> iter=list.iterator();
			  while(iter.hasNext())
			  {
				  System.out.println("jobname"+iter.next().getJob_name());
				  
				  
			  	}
				md.addObject("requestpositions",list);
				md.addObject("jobbean",jobbean);
				
				
				
				
				md.setViewName("requestposition");
		
				return md;
				
		}
		
		}
	
//	@RequestMapping(method=RequestMethod.POST)
//	public ModelAndView nextposition(Jobs jobbean)
//	{
//		System.out.println("In post methoid of position");
//		ModelAndView md=new ModelAndView();
//		//String name=jobbean.getCheck();
//		//System.out.println("name:"+name);
//		Session session1=(Session)SessionUtility.GetSessionConnection();
//		Criteria cr = session1.createCriteria(Jobs.class)
//			    .setProjection(Projections.projectionList()
//			      .add(Projections.property("job_name"), "job_name"))
//			    .setResultTransformer(Transformers.aliasToBean(Jobs.class));
//
//			  List<Jobs> list = cr.list();
//			  Iterator<Jobs> iter=list.iterator();
//		  while(iter.hasNext())
//		  {
//			  System.out.println("jobname"+iter.next().getJob_name());
//			  
//			  
//		  	}
//		  
//		  
//		  /*
//			Criteria cr1 = session1.createCriteria(Jobs.class)
//				    .setProjection(Projections.projectionList()
//				      .add(Projections.property("job_experience"), "job_experience"))
//				    .setResultTransformer(Transformers.aliasToBean(Jobs.class));
//
//				  List<Jobs> list1 = cr1.list();
//				  Iterator<Jobs> iter1=list1.iterator();
//			  while(iter1.hasNext())
//			  {
//				  System.out.println("jobexperience"+iter1.next().getJob_experience());
//				  
//			  	}  
//		  
//		md.addObject("requestexperience",list1);		*/
//		md.addObject("requestpositions",list);
//		md.addObject("jobbean",jobbean);
//		md.setViewName("requestposition");
//		return md;
//		
//	}
//	
	
}
