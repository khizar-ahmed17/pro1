package job;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

public class D 
{
	public static void main(String[] args) {
		Session session=SessionUtility.GetSessionConnection();
		session.beginTransaction();
		Criteria criteria=session.createCriteria(ServiceRequester.class);
		criteria.add(Restrictions.eq("rq_username", "ramu"));
		ServiceRequester requester=(ServiceRequester) criteria.uniqueResult();
		RequestJobs ab=new RequestJobs("a", "b", 1, "c");
		ab.setRqobj(requester);
		requester.getJobs().add(ab);
		session.save(requester);
		session.getTransaction().commit();
		
		
	
		/*
		
		
		Criteria criteria=session.createCriteria(ServiceProvider.class);
		criteria.add(Restrictions.eq("sp_username", "onecompany"));
		ServiceProvider requester=(ServiceProvider) criteria.uniqueResult();
		Jobs ab=new Jobs("a", "b", 1, "c");
		ab.setSpobj(requester);
		requester.getJobs().add(ab);
		session.save(requester);
		session.getTransaction().commit();
		
		
		*/
		
		
		
		
		
	}
}
