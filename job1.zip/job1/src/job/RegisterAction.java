package job;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("requestregister")
public class RegisterAction {

	DbOperations db=new DbOperations();
	
	@Autowired
	ServiceProvider providerbean;

	public ServiceProvider getProviderbean() {
		return providerbean;
	}

	public void setProviderbean(ServiceProvider providerbean) {
		this.providerbean = providerbean;
	}
	
	
	@Autowired
	ServiceRequester requestbean;

	public ServiceRequester getRequestbean() {
		return requestbean;
	}

	public void setRequestbean(ServiceRequester requestbean) {
		this.requestbean = requestbean;
	}

	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView regiter()
	{
		ServiceProvider providerbean=new ServiceProvider();
		ModelAndView md=new ModelAndView();
		md.addObject("providerbean",providerbean);
		md.addObject("requestbean",requestbean);
		md.setViewName("registration");
		return md;
	}
	
	

	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView RequestAction(ServiceProvider providerbean,ServiceRequester requestbean)
	{
		System.out.println("am here");
		ModelAndView mdl=new ModelAndView();
		
		if(db.checkuser(requestbean.getRq_username().toString().trim()))
		{
			mdl.setViewName("login");
		}
		else
		{
			db.InsertDatabase(requestbean.getRq_name(),requestbean.getRq_username(),requestbean.getRq_password(),
					requestbean.getRq_email(),requestbean.getRq_contact(),requestbean.getRq_address());
			mdl.setViewName("login");
		}
		
		mdl.addObject("providerbean",providerbean);
		mdl.addObject("requestbean",requestbean);
		ServiceProvider userbean=new ServiceProvider();
		mdl.addObject("userbean",userbean);
		
		return mdl;
		
	}
	
	
	
	
	
}
