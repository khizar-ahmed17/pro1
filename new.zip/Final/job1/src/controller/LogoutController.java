package controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import job.ServiceProvider;
import job.ServiceRequester;
import database.HiberOperations;

@Controller
@RequestMapping("logout")
public class LogoutController 
{

	HiberOperations db=new HiberOperations();
	@Autowired
	ServiceProvider userbean;

	public ServiceProvider getUserbean() {
		return userbean;
	}


	public void setUserbean(ServiceProvider userbean) {
		this.userbean = userbean;
	}
	
	@Autowired
	ServiceRequester requestbean;
	public ServiceRequester getRequestbean() {
		return requestbean;
	}


	public void setRequestbean(ServiceRequester requestbean) {
		this.requestbean = requestbean;
	}


	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView logoutAction(HttpSession session)
	{
		ServiceProvider userbean=new ServiceProvider();
		ServiceRequester requestbean=new ServiceRequester();
		String uname=session.getAttribute("username").toString().trim();
		ModelAndView mdl=new ModelAndView();
		db.changestatus(uname, 0);
		session.invalidate();
		mdl.setViewName("login");
		mdl.addObject("userbean",userbean);
		mdl.addObject("requestbean",requestbean);
		return mdl;
	}
}
