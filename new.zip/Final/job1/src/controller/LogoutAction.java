package controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import job.ServiceProvider;
import job.ServiceRequester;
import database.DbOperations;

@Controller
@RequestMapping("requestlogout")
public class LogoutAction
{

	DbOperations db=new DbOperations();
	@Autowired
	ServiceRequester requestbean;;

	public ServiceRequester getRequestbean() {
		return requestbean;
	}

	public void setRequestbean(ServiceRequester requestbean) {
		this.requestbean = requestbean;
	}
	
	

	@Autowired
	ServiceProvider userbean;
	
	public ServiceProvider getUserbean() {
		return userbean;
	}

	public void setUserbean(ServiceProvider userbean) {
		this.userbean = userbean;
	}

	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView logoutAction(HttpSession session)
	{
		ServiceRequester requestbean=new ServiceRequester();
		ServiceProvider userbean=new ServiceProvider();
		String uname=session.getAttribute("username").toString().trim();
		System.out.println(uname);
		ModelAndView mdl=new ModelAndView();
		db.changestatus(uname, 0);
		session.invalidate();
		mdl.setViewName("login");
		mdl.addObject("requestbean",requestbean);
		mdl.addObject("userbean",userbean);
		return mdl;
	}
}

