package controller;

import java.util.Set;

import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import job.Jobs;
import job.RequestJobs;
import job.ServiceProvider;
import database.SessionUtility;
import database.DbOperations;

@Controller
@RequestMapping("postjobs")
public class ProviderPostJob {
	
	DbOperations db=new DbOperations();
	
	@Autowired
	RequestJobs requestbean;

	
	public RequestJobs getRequestbean() {
		return requestbean;
	}


	public void setRequestbean(RequestJobs requestbean) {
		this.requestbean = requestbean;
	}


	@Autowired
	Jobs jobbean;

	public Jobs getJobbean() {
		return jobbean;
	}


	public void setJobbean(Jobs jobbean) {
		this.jobbean = jobbean;
	}


	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView getmethod()
	{
		System.out.println("am here");
		RequestJobs requestbean=new RequestJobs();
		Jobs jobbean=new Jobs();
		//ServiceRequester requestbean=new ServiceRequester();
		//ServiceProvider userbean=new ServiceProvider();
		ModelAndView mdlvie=new ModelAndView();
		mdlvie.setViewName("addjob");
		mdlvie.addObject("requestbean",requestbean);
		mdlvie.addObject("jobbean",jobbean);
	//	mdlvie.addObject("userbean",userbean);
		
		return mdlvie;
	}
	
	
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView userbeandemo(RequestJobs requestbean,Jobs jobbean,HttpSession session1)
	{
		System.out.println("In post method");
		
		ModelAndView mdlvie=new ModelAndView();
		String uname=session1.getAttribute("username").toString().trim();
		
		Session session=SessionUtility.GetSessionConnection();
		session.beginTransaction();
		Criteria criteria=session.createCriteria(ServiceProvider.class);
		criteria.add(Restrictions.eq("sp_username", uname));
		ServiceProvider requester=(ServiceProvider) criteria.uniqueResult();
		Jobs ab=new Jobs(jobbean.getJob_name(),
				jobbean.getJob_specialization(), jobbean.getJob_amount(),
				jobbean.getJob_experience());
		ab.setSpobj(requester);
		requester.getJobs().add(ab);
		session.save(requester);
		session.getTransaction().commit();
		
		mdlvie.addObject("requestbean",requestbean);
		mdlvie.addObject("jobbean",jobbean);
		mdlvie.setViewName("inindex");
		
		
		
//		System.out.println("Session username:"+uname);
//	
//        ServiceRequester rqobj= requestbean.getRqobj();
//        System.out.println("ReqiestObj:"+rqobj);
//       // Set<RequestJobs> obj=  requester.getJobs();
//		System.out.println(reqid);
//		System.out.println(requestbean.getJob_name());
//		System.out.println(requestbean.getJob_specialization());
//		System.out.println(requestbean.getJob_experience());
//		System.out.println(requestbean.getJob_amount());
//		System.out.println();
//		mdlvie.setViewName("inindex");
//		mdlvie.addObject("requestbean",requestbean);
//		mdlvie.addObject("jobbean",jobbean);
		
		return mdlvie;
		
	}
	

}
