package controller;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import job.RequestJobs;
import database.SessionUtility;



@Controller
@RequestMapping("position")
public class PositionController
{
	@Autowired
	RequestJobs jobbean;

	public RequestJobs getJobbean() {
		return jobbean;
	}

	public void setJobbean(RequestJobs jobbean) {
		this.jobbean = jobbean;
	}

	
	
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView movetoposition()
	{
			System.out.println("In Get method of position");
			ModelAndView mdlv=new ModelAndView();
			RequestJobs jobbean=new RequestJobs();
			mdlv.setViewName("hello");
			return mdlv;
		
		}
	
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView nextposition(RequestJobs jobbean)
	{
		ModelAndView md=new ModelAndView();
		Session session1=(Session)SessionUtility.GetSessionConnection();
		Criteria cr = session1.createCriteria(RequestJobs.class)
		    .setProjection(Projections.projectionList()
		      .add(Projections.property("job_specialization"), "job_specialization")
		      .add(Projections.property("job_experience"), "job_experience"))
		    .setResultTransformer(Transformers.aliasToBean(RequestJobs.class));

		@SuppressWarnings("unchecked")
		List<RequestJobs> results = cr.list();
		Iterator<RequestJobs> iter=results.iterator();
		  while(iter.hasNext())
		  	{
			  System.out.println("job specialization"+iter.next().getJob_specialization());
			  System.out.println("job experience:"+iter.next().getJob_experience());
			  
			  
		  	}
		
	
		  
		 
		md.addObject("positions",results);
		md.addObject("jobbean",jobbean);
		md.setViewName("hello");
		return md;
		
	}
	
	
}
