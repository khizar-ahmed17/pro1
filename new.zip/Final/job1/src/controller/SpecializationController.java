package controller;

import java.util.Iterator;

//This Method is used to retrieve the name of the persoon who is specialized in partiocular jobs

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import job.RequestJobs;
import job.ServiceRequester;
import database.SessionUtility;



@Controller
@RequestMapping("specialization")
public class SpecializationController 
{
	@Autowired
	RequestJobs jobbean;

	public RequestJobs getJobbean() {
		return jobbean;
	}

	public void setJobbean(RequestJobs jobbean) {
		this.jobbean = jobbean;
	}

	
	
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView movetoposition()
	{
			System.out.println("In Get method of Specialization");
			ModelAndView mdlv=new ModelAndView();
			mdlv.setViewName("specialization");
			return mdlv;
		
		}
	
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView nextposition(RequestJobs jobbean)
	{
		ModelAndView md=new ModelAndView();
		Session session1=(Session)SessionUtility.GetSessionConnection();
//		Criteria cr=session1.createCriteria(ServiceRequester.class,"ser");
//		cr.createAlias("ser.jobs", "ad");
//		cr.add(Restrictions.eq("ad.job_specialization","Java"));	
//		List<ServiceRequester> results=cr.list();
//		Iterator<ServiceRequester> iter=results.iterator();
//		if(iter.hasNext())
//		{
//			System.out.println(iter.next().getRq_name());
//		}
		
		Criteria cr=session1.createCriteria(ServiceRequester.class,"ser");
		cr.createAlias("ser.jobs", "ad");
		cr.add(Restrictions.eq("ad.job_specialization","Java"));	
		@SuppressWarnings("unchecked")
		List<ServiceRequester> ad=cr.list();
		Iterator<ServiceRequester> it=ad.iterator();
		System.out.println(ad);
		if(it.hasNext())
		{
			System.out.println("in loop:Specialization");
			System.out.println(it.next().getRq_name());
		}
		
		md.addObject("specialization",ad);
		System.out.println("Object added Successfully");
		md.addObject("jobbean",jobbean);
		md.setViewName("specialization");
		return md;
		
	}
	
	
	
	
}
