package job;

import javax.persistence.GeneratedValue;

import org.springframework.stereotype.Controller;

@Controller
public class RequestJobs 
{
	@GeneratedValue
	private int job_id;
	private String job_name;
	private String job_experience;
	private int job_amount;
	private String job_specialization;
	private ServiceRequester rqobj;
	public int getJob_id() {
		return job_id;
	}
	public void setJob_id(int job_id) {
		this.job_id = job_id;
	}
	public String getJob_name() {
		return job_name;
	}
	public void setJob_name(String job_name) {
		this.job_name = job_name;
	}
	public String getJob_experience() {
		return job_experience;
	}
	public void setJob_experience(String job_experience) {
		this.job_experience = job_experience;
	}
	public int getJob_amount() {
		return job_amount;
	}
	public void setJob_amount(int job_amount) {
		this.job_amount = job_amount;
	}
	public String getJob_specialization() {
		return job_specialization;
	}
	public void setJob_specialization(String job_specialization) {
		this.job_specialization = job_specialization;
	}
	public ServiceRequester getRqobj() {
		return rqobj;
	}
	public void setRqobj(ServiceRequester rqobj) {
		this.rqobj = rqobj;
	}
	public RequestJobs(String job_name, String job_experience, int job_amount, String job_specialization) {
		super();
		this.job_name = job_name;
		this.job_experience = job_experience;
		this.job_amount = job_amount;
		this.job_specialization = job_specialization;
	}
	public RequestJobs() {
		// TODO Auto-generated constructor stub
	}
	

}
